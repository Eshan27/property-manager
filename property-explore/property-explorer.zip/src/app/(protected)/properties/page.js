"use client";
import PropertyTable from "@/components/propertyHome/PropertyTable";

export default function PropertiesPage() {
  return (
    <>
    <div className="max-w-full">
    <PropertyTable />
    </div>
    </>
  );
}
